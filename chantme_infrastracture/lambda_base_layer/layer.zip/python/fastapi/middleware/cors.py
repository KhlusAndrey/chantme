from starlette.middleware.cors import CORSMiddleware as CORSMiddleware  # noqa
